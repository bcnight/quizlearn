import requests, json
import time
def soal1_mm():
    time.sleep(1)
    correct_answer = "b"
    print('-'*30)
    print("1. Multimedia adalah kombinasi dari..")
    print("  a. User, grafis, BIOS, dan suara")
    print("  b. Teks, grafis, seni, suara, animasi, dan video")
    print("  c. Suara, animasi, blog, banner, dan CMOS")
    print("  d. Natrium klorida, NaCl, H2O dan video")
    print("  e. elemen air dan api okwokw")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)


def soal2_mm():
    time.sleep(1)
    correct_answer = "c"
    print('-'*30)
    print("2. Presentasi Multimedia dapat meliputi...")
    print("  a. Judul multimedia")
    print("  b. Piranti authoring")
    print("  c. Non linier interaktif dan pasif")
    print("  d. Atta Halilintar")
    print("  e. Film dan cetak ")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal3_mm():
    time.sleep(1)
    correct_answer = "c"
    print('-'*30)
    print("3. Sebuah struktur Multimedia dimana pengguna bernavigasi sesuai urutan dari 1 ")
    print("   frame atau bite informasi ke yang lainnya disebut.......")
    print("  a. Bentuk non linier")
    print("  b. Bentuk vector")
    print("  c. Bentuk Aljabar")
    print("  d. Bentuk Linier")
    print("  e. Bentuk Algoritma")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal4_mm():
    time.sleep(1)
    correct_answer = "a"
    print('-'*30)
    print("4. Proyek Multimedia ketika dipublikasikan disebut.....")
    print("  a. Judul multimedia")
    print("  b. Kalimat Multimedia")
    print("  c. Susunan Multimedia")
    print("  d. Uraian Multimedia")
    print("  e. Abang Tampan ")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal5_mm():
    time.sleep(1)
    correct_answer = "a"
    print('-'*30)
    print("5. Multimedia mampu..., kecuali:")
    print("  a. Mengubah Cara Berpakaian")
    print("  b. Mengubah Cara Belanja")
    print("  c. Mengubah Tempat Bekerja")
    print("  d. Atta Halilintar")
    print("  e. Membuat Youtuber")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def collection_of_questions_mm():
    soal1_mm()
    soal2_mm()
    soal3_mm()
    soal4_mm()
    soal5_mm()
