import requests, json
import time

def soal1_tkj():
    time.sleep(1)
    correct_answer = "b"
    print('-'*30)
    print("1. Subnet Mask yang dapat digunakan pada IP kelas B adalah . . .")
    print("  a. 255.0.0.0 ")
    print("  b. 255.255.0.0 ")
    print("  c. 255.255.255.248 ")
    print("  d. 255.255.255.0 ")
    print("  e. 000.0000.0000.00000 ")
    jawaban1 = str(input(" Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)


def soal2_tkj():
    time.sleep(1)
    correct_answer = "a"
    print('-'*30)
    print("2. Alat yang berfungsi untuk menghubungkan 2 jaringan dengan segmen yang berbeda adalah ...")
    print("  a. Router ")
    print("  b. Switch ")
    print("  c. Hub ")
    print("  d. Access Point ")
    print("  e. LAN ")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah ", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal3_tkj():
    time.sleep(1)
    correct_answer = "d"
    print('-'*30)
    print("3. Subnet Mask yang dapat digunakan pada IP kelas C adalah . . .")
    print("  a. 255.0.0.0")
    print("  b. 255.255.0.0")
    print("  c. 255.255.255.248")
    print("  d. 255.255.255.0")
    print("  e. 000.0000.0000.00000")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal4_tkj():
    time.sleep(1)
    correct_answer = "e"
    print('-'*30)
    print("4. Salah satu tipe jaringan komputer yang umum dijumpai adalah....")
    print("  a. Star")
    print("  b. Bus")
    print("  c. WAN")
    print("  d. Wireless")
    print("  e. Client Server")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal5_tkj():
    time.sleep(1)
    correct_answer = "e"
    print('-'*30)
    print("5. Berikut ini jenis topologi jaringan komputer, kecuali ...")
    print("  a. Star")
    print("  b. Bus")
    print("  c. Ring")
    print("  d. Mesh")
    print("  e. Three")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def collection_of_questions_tkj():
    soal1_tkj()
    soal2_tkj()
    soal3_tkj()
    soal4_tkj()
    soal5_tkj()
