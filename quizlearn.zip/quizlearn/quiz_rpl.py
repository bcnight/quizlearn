import requests
import time
def soal1_rpl():
    time.sleep(1)
    correct_answer = "a"
    print('-'*40)
    print("1. sekumpulan program yang dibangun untuk melayani program lain adalah ...")
    print("  a. Perangkat Lunak System")
    print("  b. Perangkat Lunak Bisnis")
    print("  c. Perangkat Lunak Teknik dan Ilmu Pengetahuan")
    print("  d. Perangkat Lunak yang Dilekatkan")
    print("  e. Perangkat keras")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal2_rpl():
    time.sleep(1)
    correct_answer = "b"
    print('-'*30)
    print("2. seluruh perintah yang digunakan untuk memproses informasi ...")
    print("  a. Aplikasi")
    print("  b. Perangkat Lunak")
    print("  c. Desain")
    print("  d. Analisa")
    print("  e. MBAH GOOGLE")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal3_rpl():
    time.sleep(1)
    correct_answer = "a"
    print('-'*30)
    print("3. Perangkat lunak mempuantai dua hal pokok adalah . . .")
    print("  a. Konsep dasar rekayasa perangkat lunak")
    print("  b. Proses dan metode perangkat lunak")
    print("  c. Evaluasi perkembangan software")
    print("  d. Karakteristik dan atribut perangkat lunak")
    print("  e. MBAH GOOGLE")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal4_rpl():
    time.sleep(1)
    correct_answer = "c"
    print('-'*30)
    print("4. YouTube di buat dengan bahasa ?")
    print("  a. Inggris")
    print("  b. Belanda")
    print("  c. Python")
    print("  d. Java")
    print("  e. MBAH YOUTUBE")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def soal5_rpl():
    time.sleep(1)
    correct_answer = "d"
    print('-'*30)
    print("5. Game kebanyakan dibuat dengan bahasa ? ")
    print("  a. Bahasa Jawa")
    print("  b. Bahasa Cina")
    print("  c. Bash")
    print("  d. C++")
    print("  e. Tanya Google")
    jawaban1 = str(input("Jawaban => "))

    global point
    global form_jawaban_benar
    if jawaban1 == correct_answer:
        time.sleep(1)
        print('-'*30)
        print(form_jawaban_benar)
        point += 20
    else:
        time.sleep(1)
        print("Jawaban Salah, Jawaban yang benar adalah", correct_answer)

    time.sleep(1)
    print("Point kamu sekarang: ", point)
    print()
    time.sleep(1)

def collection_of_questions_rpl():
    soal1_rpl()
    soal2_rpl()
    soal3_rpl()
    soal4_rpl()
    soal5_rpl()
